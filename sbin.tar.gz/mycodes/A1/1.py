import Adafruit_BBIO.GPIO as g
import time


g.setup("P8_26",g.OUT)  #yellow
g.output("P8_26",g.LOW)
 
g.setup("P8_10",g.OUT) #red
g.output("P8_10",g.HIGH)

g.setup("P8_9",g.OUT) #green
g.output("P8_9",g.LOW)

g.setup("P8_14",g.IN)
g.setup("P8_18",g.IN)
g.setup("P8_13",g.IN)
print "First floor"
x=1
while True:
        if(x==1):
                if(g.input("P8_18")==1):
			print "second floor"
			g.output("P8_26",g.HIGH)
			time.sleep(1)
			g.output("P8_10",g.LOW)
			x=2
			continue
		if(g.input("P8_13")==1):
			print "second floor"
			g.output("P8_26",g.HIGH)
			time.sleep(1)
			print "third floor"
			g.output("P8_9",g.HIGH)
			time.sleep(1)
			g.output("P8_10",g.LOW)
			g.output("P8_26",g.LOW)
			x=3
			continue

	if(x==2):
		if(g.input("P8_14")==1):
			print "first floor"
			g.output("P8_10",g.HIGH)
			time.sleep(1)
			g.output("P8_26",g.LOW)
			x=1
			continue
		if(g.input("P8_13")==1):
			print "third floor"
			g.output("P8_9",g.HIGH)
			time.sleep(1)
			g.output("P8_26",g.LOW)
			x=3
			continue
	if(x==3):
                if(g.input("P8_14")==1):
			print "first floor"
			g.output("P8_26",g.HIGH)
			time.sleep(1)
			g.output("P8_10",g.HIGH)
			time.sleep(1)
			g.output("P8_9",g.LOW)
			g.output("P8_26",g.LOW)
			x=1
			continue
		if(g.input("P8_18")==1):
			print "second floor"
			g.output("P8_26",g.HIGH)
			time.sleep(1)
			g.output("P8_9",g.LOW)
			x=2
			continue
	





