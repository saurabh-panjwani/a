import java.io.*;
import java.net.*;
class my_server implements Runnable
{
	Socket obj;
	my_server(Socket object)
	{
		obj = object;
	}
	public void run()
	{
		try
		{
			while(true)
			{
				DataInputStream in = new DataInputStream(obj.getInputStream());
				String answer=in.readUTF();

				DataOutputStream out = new DataOutputStream(obj.getOutputStream());
				out.writeUTF(answer);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception :"+ e );
		}
	}
}
public class Server
{
	public static void main(String args[])
	{
		try
		{
			ServerSocket sever =new ServerSocket(1235);
			while(true)
			{
				Socket obj = sever.accept();
				my_server client = new my_server(obj);
				Thread thread = new Thread(client);
				thread.start();
			}
		}
		catch(Exception e)
		{
			System.out.println(	"error 2");
		}
	}
}
