import java.io.*;
import java.net.*;
class Client
{
	public static void main(String args[])
	{
		BufferedReader ip=new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Socket object= new Socket("localhost",1235);
			while(true)
			{
				String message = ip.readLine();

				DataOutputStream out = new DataOutputStream(object.getOutputStream());
				out.writeUTF(message);

				DataInputStream in = new DataInputStream(object.getInputStream());
				System.out.println("Message from Server: "+in.readUTF());
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception "+ e);
		}		
	}
}