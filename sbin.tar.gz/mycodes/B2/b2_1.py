import os
import shutil
import urllib2
from contextlib import closing
import ftplib
from ftplib import FTP 
from ftplib import FTP_TLS
bbbip="192.168.7.2"
while True:
	op=input("Enter 1 to transfer file from Host to BBB.\n2 to transfer BBB to Host.\n3 to downlaod from FTP.\n")
	if op==1:
	        print "Sending file from Host to BBB."
        	file=raw_input("Enter file to transfer.")
        	os.system("scp /home/cnlab/3428/"+file+" root@"+bbbip+":/root/")
        	os.system("ssh "+bbbip+" ls /root/")
        	print "Transfer successful"
		os.system("exit")
	elif op==2:
        	print "Sending file from BBB to Host."
        	os.system("ssh "+bbbip+" ls /root/")
        	file=raw_input("Enter file to Transfer.")
		os.system("exit")
        	os.system("scp /root/"+file+" cnlab@192.168.5.14:/home/cnlab/Documents/")
        	os.system("ls /home/cnlab/3428/")
        	print "Transfer successful."
	
	elif op==3:
		ftp=ftplib.FTP('192.168.5.101','tecomp','tecomp')
		file_path=raw_input("Enter path to Download.")
		with closing(urllib2.urlopen('ftp://192.168.5.101/../Mission&Vision/'+file_path)) as r:
   			with open('file_downloaded', 'wb') as f:
        			shutil.copyfileobj(r, f)
		ftp.quit()
		os.system("ls")
		print "File downloaded in file named *file_downloaded*"
