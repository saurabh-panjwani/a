import time

def Factorial(x):
	i=1
	product=1
	while(i<=x):
		product=product*i
		i=i+1
	return product
start_time=time.time()
x=input("Enter a number:")
	
print "The factorial is", Factorial(x)
print "Time taken is %s seconds " % (time.time()-start_time)

