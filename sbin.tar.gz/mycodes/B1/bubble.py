import time

def Bubblesort(list):
	for passnum in range(len(list)-1,0,-1):
		for i in range(passnum):
			if list[i]>list[i+1]:
				temp=list[i]
				list[i]=list[i+1]
				list[i+1]=temp
list=[10,5,6,34,2,1]
start_time=time.time()
Bubblesort(list)
print(list)
print "Time taken by Bubble Sort is %s seconds" % (time.time()-start_time)
			
