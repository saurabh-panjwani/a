import os



os.system("cpufreq-set -f 300Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd.py")


os.system("cpufreq-set -f 600Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd.py")

os.system("cpufreq-set -f 800Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd.py")

os.system("cpufreq-set -f 1000Mhz")
os.system("python fact.py")
os.system("python bubble.py")
os.system("python gcd.py")
