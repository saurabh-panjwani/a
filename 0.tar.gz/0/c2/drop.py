#!/usr/python
import os
import sys
import Tkinter

def sap1():
	os.system("sudo -i")
	name=raw_input("Enter name of directory to delete:")
	print ("Deleting directory...")
	os.system("./dropbox_uploader.sh delete"+name+"")
	print ("Operation completed successfully")


class simple_app(Tkinter.Tk):
	
	def __init__(self,parent):
		Tkinter.Tk.__init__(self.parent)
		self.parent=parent
		self.initialize()
	
	def initialize(self):
		self.grid()
	
		button=Tkinter.Button(self,text="Delete",command=sap1)
		button.grid(column=1,row=1)
		
		button=Tkinter.Buttom(self,text="Create Directory",command=sap2)
		button.grid(column=1,row=2)
		
		button=Tkinter.Button(self,text="List Directories",command=sap3)
		button.grid(column=1,row=3)
		
		button=Tkinter.Button(self,text="Exit",command=sap4)
		button.grid(column=1,row=4)

		button=Tkinter.Button(self,txt="Upload",command=sap5)
		button.grid(column=1,row=5)
		
		button=Tkinter.Button(self.text="View",command=sap6)
		button.grid(column=1,row=6)



if __name__="__main__":
	app=simple_app(None)
	app.title("Cloud Storage Commands")
	app.mainloop()
