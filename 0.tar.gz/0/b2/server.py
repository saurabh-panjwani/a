from flask import Flask , request, render_template

app = Flask(__name__)

@app.route('/')
def fun():
    return render_template('index.html',msg="")
    
@app.route('/check/',methods=['POST'])
def check():
    ab = checker(request.form['string'])
    return render_template('index.html',msg=ab)

def checker(str1):
	file_data=""
	with open("data.txt","r") as f:
		file_data=f.read()
		
	print "anuja",file_data,"ghg"
	
	unwanted="!@#$%^&*()_+="
	for i in unwanted:
		file_data=file_data.replace(i,"")
		str1=str1.replace(i,"")
		
		file_data=file_data.replace("."," ")
		a=file_data.split(" ")
		#a=a[:-1]
		print "a is:",a
		str1=str1.replace("."," ")
		b=str1.split(" ")
		print "b is:",b
		a_dict={}
		b_dict={}
		for i in a:
			try:
				a_dict[i]+=1
			except KeyError: 
				a_dict[i]=1
		print a_dict
		for j in b:
			try:
				b_dict[j]+=1
			except KeyError:
				b_dict[j]=1
		print b_dict
		
		count=0
		for b_key in b_dict.keys():
			if b_key in a_dict.keys():
				count+=b_dict[b_key]
		percentage = str(float(count)/(len(b))*100.0)+"%"
		return percentage
	
				

if __name__=="__main__":
    app.run(debug=True)
