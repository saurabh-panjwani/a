import json


def isattack(board,r,c):

	for i in range(r):
		if(board[i][c]==1):
			return True


	#left diagonal
	i=r-1
	j=c-1

	while((i>=0) and (j>=0)):
		if(board[i][j]==1):
			return True
		i=i-1
		j=j-1



	#right diagonal

	i=r-1
	j=c+1

	while((i>=0)and (j<8)):
		if(board[i][j]==1):
			return True

		i=i-1
		j=j+1


	return False





def solve(board,row):
	i=0#start placing from column 0
	while(i<8):
		if(not isattack(board,row,i)):
			board[row][i]=1

			if(row==7):
				return True

			else:
				if(solve(board,row+1)):
					return True

				else:
					board[row][i]=0

		i=i+1

		
	if(row==8):
		return False




def printboard(board):

	for i in range(8):
		for j in range(8):
			print str(board[i][j]) + " ",
		print "\n"	






#chess board

board=[[0 for x in range(8)] for x in range(8)]

def main():
	data=[]#array containing o/p positions
	fd=open("input.json","r")
	data=json.load(fd)
	#print(data)
	
	#cornercase
	if(data['start']<0 or data["start"]>7):
		print"Invalid input"
		exit()


	#defining position in row 0
	board[0][data["start"]]=1
	

	if(solve(board,1)):
		print("8 queens solved")
		print("===Board Configuration===")
		printboard(board)


	else:
		print "8 queens not solved"


main()
	
