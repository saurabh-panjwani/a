from flask import Flask,render_template,request

app=Flask(__name__)

file=open("text1.txt","r")
text1=[]
for line in file:
	text1.append(line.strip())

file=open("text2.txt","r")
text2=[]
for line in file:
	text2.append(line.strip())

file=open("text3.txt","r")
text3=[]
for line in file:
	text3.append(line.strip())



@app.route('/')
def homepage():
	return render_template("index.html")

@app.route('/check',methods=['GET','POST'])
def check():
	text=request.form["plagarismtext"]
	lines=text.split("\n")
	textlen=len(lines)
	

	matches=0
	textdatabase=[text1,text2,text3]
	for file in textdatabase:
		for line in lines:
			if line.strip() in file:
				matches+=1

	percentage=(float(matches)/textlen)*100
	per=str(percentage)
	return per
	
	

if __name__ == "__main__":
	app.run(debug='True')
