import unittest

class mytest(unittest.TestCase):
	def setUp(self):
		self.binary_2=search([1,2,3,4,5,10])
	def test_0(self):
		self.assertEqual(self.binary_2.binsearch(3,0,4),2)
	def test_1(self):
		self.assertEqual(self.binary_2.binsearch_nonre(3,0,4),2)


class search:
	a=[]
	def __init__(self,arr):
		self.a=arr

	def binsearch(self,num,l,r):
		mid=(l+r)/2
		if(l>r):
			return -1
		elif(self.a[mid]==num):
			return mid
		elif(self.a[mid]>num):
			r=mid-1
		else:
			l=mid+1
		return self.binsearch(num,l,r)

	def binsearch_nonre(self,num,l,r):

		while(r>=l):
			mid=(l+r)/2
			if(self.a[mid]==num):
				return mid
			elif(self.a[mid]>num):
				r=mid-1
			else:
				l=mid+1
		return -1



def main():
	filename=raw_input("Enter name of file")
	arr=[]
	obj=open(filename,'r')
	for data in obj:
		arr.append(int(data))
	arr.sort()
	print arr
	
	obj=search(arr)

	ch=raw_input("Enter choice\n1.Search with recursion\n2.Search without recursion")
	no=input("Enter no to be searched")

	if ch=='1':
		val=obj.binsearch(no,0,len(arr)-1)

	if ch=='2':
		val=obj.binsearch_nonre(no,0,len(arr)-1)

	if val==-1:
		print "Not found"
	else:
		print "Found no at", val

main()
unittest.main()
