import xml.etree.ElementTree as et
import threading
import time
import unittest


'''class mytest(unittest.TestCase):
	
	def setUp(self):
		arr=[3,4,7,5,89]
		self.quick=Sort(arr)
	def test_0(self):
		self.assertEqual(self.quick.quicksort(0,4),[3,4,5,7,89])
'''	

class Sort:
    arr=[]
    def __init__(self,a):
        self.arr=a
    
    def partition(self,low,high):
        i=low
        j=high
        pivot=self.arr[low]
        while(i<j):
            while(self.arr[i]<=pivot and i<j):
                i=i+1
            while(self.arr[j]>pivot and i<=j):
                j=j-1
            if(i<=j):
                temp=self.arr[i]
                self.arr[i]=self.arr[j]
                self.arr[j]=temp

        temp=self.arr[j]
        self.arr[j]=self.arr[low]
        self.arr[low]=temp
        return j

    def quicksort(self,l,r):
        if(l<r):
            ind=self.partition(l,r)
            thread1=threading.Thread(target=self.quicksort,args=(l,ind-1))
            thread2=threading.Thread(target=self.quicksort,args=(ind+1,r))
            thread1.start()
            thread2.start()
            thread1.join()
            print (thread1.getName())
            thread2.join()
            print (thread2.getName())


    def display(self):
        print (self.arr)


class Application:

    def readxml(self,filename):
        name=filename.split('.')
        if(name[1]=='xml'):
            tree=et.parse(filename)
            root=tree.getroot()
            a=list(map(int,root.text.split()))
            obj=Sort(a)
            start_time=time.time()
            obj.quicksort(0,len(a)-1)    
            obj.display()
            print("Time required %s seconds"%(time.time()-start_time))

    def main(self):
        filename=raw_input("enter file name:")
        self.readxml(filename)

a=Application()
a.main()

#unittest.main()
