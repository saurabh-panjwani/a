from bitstring import BitArray


def booths(a,b,len1,len2):
	total=len1+len2+1
	Minit=BitArray(int=a,length=total)
	M2sinit=BitArray(int=-a,length=total)
	Mfinal=Minit<<(len2+1)
	M2sfinal=M2sinit<<(len2+1)
	Q=BitArray(int=b,length=len2)
	Q.prepend(BitArray(int=0,length=len1))
	AQQ=Q<<(1)

	for i in range(1,len2+1):
		if(AQQ[-2:]=='0b01'):
			AQQ=BitArray(int=AQQ.int+Mfinal.int,length=total)
		elif(AQQ[-2:]=='0b10'):
			AQQ=BitArray(int=AQQ.int+M2sfinal.int,length=total)
		AQQ=BitArray(int=(AQQ.int>>1),length=total)
		#AQQ=BitArray(int=(AQQ.int>>1),length=AQQ.len)



	AQQ=AQQ[:-1]
	print"Answer:",AQQ.int
	print"Decinal:",AQQ.bin


while True:
	a=input("Enter number")
	len1=input("Enter length")
	b=input("Enter number")
	len2=input("Enter length")
	
	booths(a,b,len1,len2)
