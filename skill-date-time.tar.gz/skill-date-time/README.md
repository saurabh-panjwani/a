## date time skill
Gives back the current date time information

## Description 
Gives back the current time

## Examples 
* "what time is it"

## Credits 
Mycroft AI
