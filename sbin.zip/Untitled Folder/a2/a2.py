import Adafruit_BBIO.GPIO as g
import time

g.setup("P8_10",g.OUT)
g.setup("P8_11",g.OUT)
g.setup("P8_12",g.OUT)

g.setup("P8_13",g.OUT)
g.setup("P8_14",g.OUT)
g.setup("P8_15",g.OUT)

g.output("P8_10",g.LOW)
g.output("P8_11",g.LOW)
g.output("P8_12",g.LOW)

g.output("P8_13",g.LOW)
g.output("P8_14",g.LOW)
g.output("P8_15",g.LOW)

while True:
	
	g.output("P8_10",g.LOW)
	g.output("P8_11",g.LOW)
	g.output("P8_12",g.HIGH)

	g.output("P8_13",g.HIGH)
	g.output("P8_14",g.LOW)
	g.output("P8_15",g.LOW)
	time.sleep(5)
	g.output("P8_11",HIGH)
	g.output("P8_12",g.LOW)
	time.sleep(5)
	g.output("P8_11",g.LOW)
	g.output("P8_10",g.HIGH)
	g.output("P8_15",g.HIGH)
	time.sleep(5)
	g.output("P8_14",g.HIGH)
	g.output("P8_15",g.LOW)
	time.sleep(5)
	
	

	
