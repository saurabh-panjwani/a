import time 
import math

start_time=time.time()
math.factorial(5)
print "Time taken is %s seconds " % (time.time()-start_time)
