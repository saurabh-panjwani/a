import fractions
import time

start_time=time.time()
fractions.gcd(55,75)
print "Time taken is %s seconds " % (time.time()-start_time)
