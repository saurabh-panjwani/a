import time

start_time=time.time()
sorted([5,4,3,2,1])
print "Time taken is %s seconds " % (time.time()-start_time)
